package com.example.day6;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Movie m1 = new Movie("Harry Potter","Daniel Radcliffe",11.5,13,"not action");
        Movie m2 = new Movie("fast & furios","Vin Diesel",14.2,15,"action");
        Movie m3 = new Movie("Joker","Joaquin Phoenix",16.0,18,"crime");
        Movie m4 = new Movie("Rocky","Sylvester Stallone",12.36,13,"sport");
        Movie m5 = new Movie("Creed","Michael B. Jordan",10.0,13,"sport");
        Movie m6 = new Movie("Ride Along","Kevin Hart - Ice Cube",11.5,15,"action");
        Movie m7 = new Movie("Back to the future","Michael J. Fox",9.0,13,"scy-fi");
        Movie m8 = new Movie("Police Academy","Steve Guttenberg",14.2,18,"comedy");
    }
}